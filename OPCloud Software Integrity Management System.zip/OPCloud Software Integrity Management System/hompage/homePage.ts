// import {Component} from '@angular/core'
// @Component({
//     selector: "home",
//     templateUrl:'./homePage.html',
//     styleUrls:['./homePage.css']
// })
// export class homePageComponent{
//     buildId: true;
//     status: false;
//     date: false;
// }
class homePage{
    buildId: true;
    status: false;
    date: false;
}